﻿Imports System.IO

Public Class LoginForm
    Private Sub LoginForm(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load the image into PictureBox1
        Dim relativePath As String = "student_login.png"
        Dim jsonFilePath As String = Path.Combine(Application.StartupPath, relativePath)
        picLogo.Image = Image.FromFile(jsonFilePath)
        picLogo.SizeMode = PictureBoxSizeMode.Zoom
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' this is just a dummy login using json file. Of course you need to create a database to check
        Dim username = txtUsername.Text
        Dim password = txtPassword.Text
        Dim service = New UserLoginService(username, password)
        Dim isExists As Boolean = service.Login()
        If (isExists) Then
            Me.Hide()
            Dim mainForm As New MainForm()
            mainForm.Show()
        Else
            MessageBox.Show(Constants.ERR_INVALID_CREDENTIALS, Constants.MSG_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

End Class
