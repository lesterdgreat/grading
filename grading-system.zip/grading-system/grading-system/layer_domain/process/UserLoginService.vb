﻿Imports Newtonsoft.Json
Imports System.IO

Public Class UserLoginService

    Private username As String
    Private password As String

    Public Sub New(user As String, pass As String)
        username = user
        password = pass
    End Sub

    Friend Function Login() As Boolean
        Dim relativePath As String = "UserLogin.json"
        Dim jsonFilePath As String = Path.Combine(Application.StartupPath, relativePath)
        Dim items As List(Of User)
        Dim isExists As Boolean = False
        Try
            ' Read JSON file content
            Dim jsonString As String = System.IO.File.ReadAllText(jsonFilePath)
            ' Deserialize JSON string into a list of items
            items = JsonConvert.DeserializeObject(Of List(Of User))(jsonString)
            isExists = items.Any(Function(u) u.username = username AndAlso u.password = password)
        Catch ex As Exception
            MessageBox.Show("Error reading or parsing JSON file: " & ex.Message)
        End Try
        Return isExists
    End Function
End Class
