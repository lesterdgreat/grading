﻿Imports System.IO
Imports Newtonsoft.Json

Public Class StudentTypeService
    Friend Function GetStudentTypeList() As List(Of StudentTypeItem)
        Dim relativePath As String = "StudentType.json"
        Dim jsonFilePath As String = Path.Combine(Application.StartupPath, relativePath)
        Dim items As List(Of StudentTypeItem) = New List(Of StudentTypeItem)
        Try
            ' Read JSON file content
            Dim jsonString As String = System.IO.File.ReadAllText(jsonFilePath)
            ' Deserialize JSON string into a list of items
            items = JsonConvert.DeserializeObject(Of List(Of StudentTypeItem))(jsonString)
        Catch ex As Exception
            MessageBox.Show("Error reading or parsing JSON file: " & ex.Message)
        End Try
        Return items
    End Function
End Class
