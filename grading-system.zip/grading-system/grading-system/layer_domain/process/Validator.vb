﻿Public Class Validator

    Public Function ValidateIfNumeric(Datagrid As DataGridView, e As DataGridViewCellValidatingEventArgs) As Boolean
        Dim isError As Boolean = False
        ' Check if the cell belongs to the specific column where you want to allow only numeric input
        If Datagrid.Columns(e.ColumnIndex).Name = "Grade" Or Datagrid.Columns(e.ColumnIndex).Name = "Unit" Then
            Dim newValue As String = e.FormattedValue.ToString()
            Dim numericValue As Integer
            If Not Integer.TryParse(newValue, numericValue) Then
                ' If the entered value is not numeric, cancel the editing process
                Datagrid.Rows(e.RowIndex).ErrorText = "Please enter a numeric value."
            ElseIf Datagrid.Columns(e.ColumnIndex).Name = "Grade" Then

            End If
        End If
        Return isError
    End Function

End Class
