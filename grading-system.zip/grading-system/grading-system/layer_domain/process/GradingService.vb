﻿
Imports System.IO

Public Class GradingService

    Private dataList As List(Of Grade) = New List(Of Grade)

    Private grade As New Grade

    Public Sub New(data As DataGridView)
        For Each row In data.Rows
            If Not row.IsNewRow AndAlso Not row.Cells(2).Value Is Nothing AndAlso Not row.Cells(3).Value Is Nothing Then
                Dim grade As New Grade()
                grade.grade = Convert.ToInt32(row.Cells(2).Value)
                grade.unitNo = Convert.ToInt32(row.Cells(3).Value)
                dataList.Add(grade)
            End If
        Next
    End Sub

    Friend Function write() As Boolean
        Dim relativePath As String = "Transaction.csv"
        Dim filePath As String = Path.Combine(Application.StartupPath, relativePath)
        Dim isSuccess As Boolean = False

        If Not File.Exists(filePath) Then
            File.Create(filePath).Close()
        End If
        Using writer As New StreamWriter(filePath, True)
            ' Loop through each row of data
            writer.WriteLine(String.Join(",", grade.totalGrade, grade.totalUnit))
        End Using
        Return isSuccess
    End Function

    Public Sub New(grade As Grade)
        Me.grade = grade
    End Sub

    Public Function ComputeTotal() As Grade
        ' Computations should be change here
        Dim totalGrade As Grade = New Grade
        Dim totalCount As Integer = 0
        Dim grades As Integer
        Dim unit As Integer
        For Each grade In dataList
            totalCount += 1
            grades += grade.grade
            unit += grade.unitNo
        Next
        totalGrade.totalSubject = totalCount
        totalGrade.totalUnit = unit
        totalGrade.totalGrade = grades / totalCount
        Return totalGrade
    End Function

End Class
