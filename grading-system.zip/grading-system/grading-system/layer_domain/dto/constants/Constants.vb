﻿Public Class Constants

    ' DataGridView for Grading Part
    Public Shared DEFAULT_GRIDCOUNT As Integer = 8
    Public Shared DATAGRID_GRADE_COL_NO As String = "No"
    Public Shared DATAGRID_GRADE_COL_SUBJECT As String = "Subject"
    Public Shared DATAGRID_GRADE_COL_GRADE As String = "Grade"
    Public Shared DATAGRID_GRADE_COL_UNIT As String = "Unit"

    ' Student Type Combo Box
    Public Shared CMB_STUD_TYPE_ID = "id"
    Public Shared CMB_STUD_TYPE_DESC = "desc"

    ' Message Box Types
    Public Shared MSG_INFO = "Info"
    Public Shared MSG_ERROR = "Error"

    ' Error messages
    Public Shared ERR_INVALID_CREDENTIALS = "Invalid credentials. Kindly try again."
    Public Shared ERR_INVALID_SUBJECT_COUNT = "Minimum of 8 subjects for Regular Student."
    Public Shared ERR_INVALID_GRADE_AVG = "Minimum average should be 90% for Irregular Student."
End Class
