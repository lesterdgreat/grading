﻿Public Class Grade
    Public studentId As Integer
    Public subjectCode As String
    Public unitNo As Integer
    Public grade As Integer
    Public totalSubject As Integer
    Public totalGrade As Double
    Public totalUnit As Integer
    Public incentives As Double
End Class
