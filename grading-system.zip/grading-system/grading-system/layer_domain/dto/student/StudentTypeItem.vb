﻿Public Class StudentTypeItem
    Public Property id As Integer
    Public Property desc As String
End Class
