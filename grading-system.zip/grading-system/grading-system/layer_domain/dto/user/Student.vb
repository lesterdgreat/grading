﻿Public Class Student
    Public studentId As Integer
    Public studentName As String
    Public section As String
    Public studentType As String
End Class
