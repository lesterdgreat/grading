﻿Public Class User
    Public id As Integer
    Public username As String
    Public password As String
End Class
