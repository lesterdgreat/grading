﻿Public Class Computation

    Private totalGrade As Double
    Private totalUnit As Double
    Private grade As Grade

    Public Sub New(grade As Grade)
        ' This call is required by the designer.
        InitializeComponent()
        ' Populate Grades and Unit and compute for cash incentives
        totalUnit = grade.totalUnit
        totalGrade = grade.totalGrade
        txtAvgGrade.Text = totalGrade.ToString + "%"
        txtTotalUnits.Text = totalUnit
        txtCashIncentives.Text = ComputeIncentives()
        Me.grade = grade
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim gradingService As New GradingService(Me.grade)
        gradingService.write()
    End Sub

    Private Function ComputeIncentives() As Double
        Dim incentives As Double = 0.0
        If (totalGrade >= 90 And totalGrade <= 95) Then
            incentives = 1500.0
        ElseIf (totalGrade >= 96) Then
            incentives = 3000.0
        End If
        Return incentives
    End Function

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class