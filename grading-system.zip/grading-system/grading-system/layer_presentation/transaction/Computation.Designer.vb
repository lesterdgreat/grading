﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Computation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        lblAvgGrades = New Label()
        Panel1 = New Panel()
        btnCancel = New Button()
        btnSubmit = New Button()
        txtCashIncentives = New TextBox()
        txtTotalUnits = New TextBox()
        txtAvgGrade = New TextBox()
        lblRemarks = New Label()
        txtRemarks = New RichTextBox()
        lblCashIncentives = New Label()
        lblTotalUnits = New Label()
        Panel1.SuspendLayout()
        SuspendLayout()
        ' 
        ' lblAvgGrades
        ' 
        lblAvgGrades.AutoSize = True
        lblAvgGrades.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblAvgGrades.Location = New Point(16, 34)
        lblAvgGrades.Name = "lblAvgGrades"
        lblAvgGrades.Size = New Size(115, 19)
        lblAvgGrades.TabIndex = 4
        lblAvgGrades.Text = "Average Grade:"
        ' 
        ' Panel1
        ' 
        Panel1.Controls.Add(btnCancel)
        Panel1.Controls.Add(btnSubmit)
        Panel1.Controls.Add(txtCashIncentives)
        Panel1.Controls.Add(txtTotalUnits)
        Panel1.Controls.Add(txtAvgGrade)
        Panel1.Controls.Add(lblRemarks)
        Panel1.Controls.Add(txtRemarks)
        Panel1.Controls.Add(lblCashIncentives)
        Panel1.Controls.Add(lblTotalUnits)
        Panel1.Controls.Add(lblAvgGrades)
        Panel1.Location = New Point(12, 12)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(417, 332)
        Panel1.TabIndex = 5
        ' 
        ' btnCancel
        ' 
        btnCancel.BackColor = Color.White
        btnCancel.FlatStyle = FlatStyle.Popup
        btnCancel.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        btnCancel.ForeColor = SystemColors.ActiveCaptionText
        btnCancel.Location = New Point(281, 274)
        btnCancel.Name = "btnCancel"
        btnCancel.Size = New Size(122, 44)
        btnCancel.TabIndex = 13
        btnCancel.Text = "&Cancel"
        btnCancel.UseVisualStyleBackColor = False
        ' 
        ' btnSubmit
        ' 
        btnSubmit.BackColor = Color.Black
        btnSubmit.FlatStyle = FlatStyle.Popup
        btnSubmit.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        btnSubmit.ForeColor = SystemColors.ButtonFace
        btnSubmit.Location = New Point(145, 274)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(122, 44)
        btnSubmit.TabIndex = 12
        btnSubmit.Text = "&Submit"
        btnSubmit.UseVisualStyleBackColor = False
        ' 
        ' txtCashIncentives
        ' 
        txtCashIncentives.Font = New Font("Segoe UI", 10F)
        txtCashIncentives.Location = New Point(145, 114)
        txtCashIncentives.Name = "txtCashIncentives"
        txtCashIncentives.Size = New Size(258, 25)
        txtCashIncentives.TabIndex = 11
        txtCashIncentives.TextAlign = HorizontalAlignment.Right
        ' 
        ' txtTotalUnits
        ' 
        txtTotalUnits.Font = New Font("Segoe UI", 10F)
        txtTotalUnits.Location = New Point(145, 74)
        txtTotalUnits.Name = "txtTotalUnits"
        txtTotalUnits.Size = New Size(258, 25)
        txtTotalUnits.TabIndex = 10
        txtTotalUnits.TextAlign = HorizontalAlignment.Right
        ' 
        ' txtAvgGrade
        ' 
        txtAvgGrade.Font = New Font("Segoe UI", 10F)
        txtAvgGrade.Location = New Point(145, 34)
        txtAvgGrade.Name = "txtAvgGrade"
        txtAvgGrade.Size = New Size(258, 25)
        txtAvgGrade.TabIndex = 9
        txtAvgGrade.TextAlign = HorizontalAlignment.Right
        ' 
        ' lblRemarks
        ' 
        lblRemarks.AutoSize = True
        lblRemarks.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblRemarks.Location = New Point(16, 151)
        lblRemarks.Name = "lblRemarks"
        lblRemarks.Size = New Size(71, 19)
        lblRemarks.TabIndex = 8
        lblRemarks.Text = "Remarks:"
        ' 
        ' txtRemarks
        ' 
        txtRemarks.Font = New Font("Segoe UI", 10F)
        txtRemarks.Location = New Point(145, 160)
        txtRemarks.Name = "txtRemarks"
        txtRemarks.Size = New Size(258, 96)
        txtRemarks.TabIndex = 7
        txtRemarks.Text = ""
        ' 
        ' lblCashIncentives
        ' 
        lblCashIncentives.AutoSize = True
        lblCashIncentives.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblCashIncentives.Location = New Point(16, 114)
        lblCashIncentives.Name = "lblCashIncentives"
        lblCashIncentives.Size = New Size(114, 19)
        lblCashIncentives.TabIndex = 6
        lblCashIncentives.Text = "Cash Incentives:"
        ' 
        ' lblTotalUnits
        ' 
        lblTotalUnits.AutoSize = True
        lblTotalUnits.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblTotalUnits.Location = New Point(16, 74)
        lblTotalUnits.Name = "lblTotalUnits"
        lblTotalUnits.Size = New Size(83, 19)
        lblTotalUnits.TabIndex = 5
        lblTotalUnits.Text = "Total Units:"
        ' 
        ' Computation
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Snow
        ClientSize = New Size(442, 360)
        Controls.Add(Panel1)
        Name = "Computation"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Computation"
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents lblAvgGrades As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents lblTotalUnits As Label
    Friend WithEvents lblRemarks As Label
    Friend WithEvents txtRemarks As RichTextBox
    Friend WithEvents lblCashIncentives As Label
    Friend WithEvents txtCashIncentives As TextBox
    Friend WithEvents txtTotalUnits As TextBox
    Friend WithEvents txtAvgGrade As TextBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnCancel As Button
End Class
