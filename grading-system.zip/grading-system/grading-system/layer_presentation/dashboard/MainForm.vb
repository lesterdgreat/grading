﻿
Imports System.Data.Common

Public Class MainForm
    Private Sub MainForm(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Populate Initial Header for GridView
        PopulateGridView()
        ' For Combo Box Details
        PopulateStudentComboBox()
    End Sub

    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If e.CloseReason = CloseReason.UserClosing Then
            e.Cancel = False
            Dim login As New LoginForm()
            login.Show()
        End If
    End Sub

    ' TODO This method should be move to Validator.vb to remove validation/business process to presentation layer
    Private Sub DataGridView1_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles DataGridView1.CellValidating
        ' Check if the cell belongs to the specific column where you want to allow only numeric input
        If DataGridView1.Columns(e.ColumnIndex).Name = "Grade" Or DataGridView1.Columns(e.ColumnIndex).Name = "Unit" Then
            Dim newValue As String = e.FormattedValue.ToString()
            Dim numericValue As Integer
            If Not Integer.TryParse(newValue, numericValue) Then
                ' If the entered value is not numeric, cancel the editing process
                DataGridView1.Rows(e.RowIndex).ErrorText = "Please enter a numeric value."
                e.Cancel = True
            ElseIf DataGridView1.Columns(e.ColumnIndex).Name = "Grade" Then
                Dim grade As Integer = Integer.Parse(newValue)
                If grade < 75 Then
                    DataGridView1.Rows(e.RowIndex).ErrorText = "Please enter a grade between 75 - 100."
                    e.Cancel = True
                End If
            End If
        End If
    End Sub

    Private Sub DataGridView1_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit
        ' Clear the error text when the cell editing is finished
        DataGridView1.Rows(e.RowIndex).ErrorText = String.Empty
    End Sub

    Private Sub DataGridView1_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles DataGridView1.RowPrePaint
        ' Get the index of the current row
        Dim rowIndex As Integer = e.RowIndex
        ' Get the cell in the first column (index 0) of the current row
        Dim cell As DataGridViewCell = DataGridView1.Rows(rowIndex).Cells(0)
        ' Populate the counter value (row index + 1) in the cell
        cell.Value = rowIndex + 1
    End Sub

    Private Sub PopulateGridView()
        Dim studentType As String = cmbStudentType.SelectedValue
        ' Set the Header of Subject Code, Grade and Unit
        Dim count As New DataGridViewTextBoxColumn()
        Dim subjectCode As New DataGridViewTextBoxColumn()
        Dim grade As New DataGridViewTextBoxColumn()
        Dim unit As New DataGridViewTextBoxColumn()

        ' Count
        count.Name = Constants.DATAGRID_GRADE_COL_NO
        count.HeaderText = Constants.DATAGRID_GRADE_COL_NO
        DataGridView1.Columns.Add(count)

        ' Subject Code
        subjectCode.Name = Constants.DATAGRID_GRADE_COL_SUBJECT
        subjectCode.HeaderText = Constants.DATAGRID_GRADE_COL_SUBJECT
        subjectCode.ValueType = GetType(String)
        DataGridView1.Columns.Add(subjectCode)

        ' Grade
        grade.Name = Constants.DATAGRID_GRADE_COL_GRADE
        grade.HeaderText = Constants.DATAGRID_GRADE_COL_GRADE
        grade.ValueType = GetType(Integer)
        DataGridView1.Columns.Add(grade)

        ' No. of Unit
        unit.Name = Constants.DATAGRID_GRADE_COL_UNIT
        unit.HeaderText = Constants.DATAGRID_GRADE_COL_UNIT
        unit.ValueType = GetType(Integer)
        DataGridView1.Columns.Add(unit)


        ' Set the AutoSizeMode property of each column to Fill
        For Each col As DataGridViewColumn In DataGridView1.Columns
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
        Next

        ' Populate Row count based on Student Type
        If studentType = Nothing Or studentType = "1" Then
            For i As Integer = 0 To Constants.DEFAULT_GRIDCOUNT - 1
                DataGridView1.Rows.Add("")
            Next
        End If
    End Sub

    Private Sub PopulateStudentComboBox()
        Dim service As StudentTypeService = New StudentTypeService()
        ' Bind data to ComboBox to service logic
        cmbStudentType.DataSource = service.GetStudentTypeList
        cmbStudentType.DisplayMember = Constants.CMB_STUD_TYPE_DESC
        cmbStudentType.ValueMember = Constants.CMB_STUD_TYPE_ID
    End Sub

    Private Sub cmbStudentType_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cmbStudentType.SelectionChangeCommitted
        ' Clear first the DataGridView before rewriting the columns/rows on change to avoid error
        DataGridView1.Columns.Clear()
        PopulateGridView()
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        Dim studentType As String = cmbStudentType.SelectedValue
        Dim gradingService As New GradingService(DataGridView1)
        Dim grades As Grade = gradingService.ComputeTotal()
        ' TODO This method should be move to Validator.vb to remove validation/business process to presentation layer
        If (studentType = Nothing Or studentType = "1") And grades.totalSubject < 8 Then
            MessageBox.Show(Constants.ERR_INVALID_SUBJECT_COUNT, Constants.MSG_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf studentType = "2" And grades.totalGrade < 90 Then
            MessageBox.Show(Constants.ERR_INVALID_GRADE_AVG, Constants.MSG_ERROR, MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim computeBox As New Computation(gradingService.ComputeTotal())
            computeBox.Show()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        DataGridView1.Columns.Clear()
        PopulateGridView()
    End Sub
End Class