﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtUsername = New TextBox()
        lblStudentName = New Label()
        lblIdNo = New Label()
        txtIdNo = New TextBox()
        cmbStudentType = New ComboBox()
        lblStudentType = New Label()
        DataGridView1 = New DataGridView()
        btnCompute = New Button()
        btnCancel = New Button()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtUsername
        ' 
        txtUsername.Font = New Font("Segoe UI", 10F)
        txtUsername.Location = New Point(122, 36)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(174, 25)
        txtUsername.TabIndex = 6
        ' 
        ' lblStudentName
        ' 
        lblStudentName.AutoSize = True
        lblStudentName.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblStudentName.Location = New Point(12, 39)
        lblStudentName.Name = "lblStudentName"
        lblStudentName.Size = New Size(104, 19)
        lblStudentName.TabIndex = 7
        lblStudentName.Text = "Student Name"
        ' 
        ' lblIdNo
        ' 
        lblIdNo.AutoSize = True
        lblIdNo.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblIdNo.Location = New Point(12, 79)
        lblIdNo.Name = "lblIdNo"
        lblIdNo.Size = New Size(82, 19)
        lblIdNo.TabIndex = 8
        lblIdNo.Text = "ID Number"
        ' 
        ' txtIdNo
        ' 
        txtIdNo.Font = New Font("Segoe UI", 10F)
        txtIdNo.Location = New Point(122, 79)
        txtIdNo.Name = "txtIdNo"
        txtIdNo.Size = New Size(174, 25)
        txtIdNo.TabIndex = 9
        ' 
        ' cmbStudentType
        ' 
        cmbStudentType.Font = New Font("Segoe UI", 10F)
        cmbStudentType.FormattingEnabled = True
        cmbStudentType.Location = New Point(442, 39)
        cmbStudentType.Name = "cmbStudentType"
        cmbStudentType.Size = New Size(174, 25)
        cmbStudentType.TabIndex = 10
        ' 
        ' lblStudentType
        ' 
        lblStudentType.AutoSize = True
        lblStudentType.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        lblStudentType.Location = New Point(340, 39)
        lblStudentType.Name = "lblStudentType"
        lblStudentType.Size = New Size(96, 19)
        lblStudentType.TabIndex = 11
        lblStudentType.Text = "Student Type"
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 134)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.Size = New Size(604, 176)
        DataGridView1.TabIndex = 12
        ' 
        ' btnCompute
        ' 
        btnCompute.BackColor = Color.Black
        btnCompute.FlatStyle = FlatStyle.Popup
        btnCompute.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        btnCompute.ForeColor = SystemColors.ButtonFace
        btnCompute.Location = New Point(352, 326)
        btnCompute.Name = "btnCompute"
        btnCompute.Size = New Size(122, 44)
        btnCompute.TabIndex = 13
        btnCompute.Text = "&Compute"
        btnCompute.UseVisualStyleBackColor = False
        ' 
        ' btnCancel
        ' 
        btnCancel.BackColor = Color.White
        btnCancel.FlatStyle = FlatStyle.Popup
        btnCancel.Font = New Font("Segoe UI", 10F, FontStyle.Bold)
        btnCancel.ForeColor = SystemColors.ActiveCaptionText
        btnCancel.Location = New Point(494, 326)
        btnCancel.Name = "btnCancel"
        btnCancel.Size = New Size(122, 44)
        btnCancel.TabIndex = 14
        btnCancel.Text = "&Cancel"
        btnCancel.UseVisualStyleBackColor = False
        ' 
        ' MainForm
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Snow
        ClientSize = New Size(630, 399)
        Controls.Add(btnCancel)
        Controls.Add(btnCompute)
        Controls.Add(DataGridView1)
        Controls.Add(lblStudentType)
        Controls.Add(cmbStudentType)
        Controls.Add(txtIdNo)
        Controls.Add(lblIdNo)
        Controls.Add(lblStudentName)
        Controls.Add(txtUsername)
        Name = "MainForm"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Main Form"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtUsername As TextBox
    Friend WithEvents lblStudentName As Label
    Friend WithEvents lblIdNo As Label
    Friend WithEvents txtIdNo As TextBox
    Friend WithEvents cmbStudentType As ComboBox
    Friend WithEvents lblStudentType As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnCompute As Button
    Friend WithEvents btnCancel As Button
End Class
